import java.util.Scanner;

/**
 *  This program runs a simple test
 *  of the CellPhone class.
 */

public class CellPhoneTest
{
   public static void main(String[] args)
   {
      String testMan;   // To hold a manufacturer
      String testMod;   // To hold a model number
      double testPrice; // To hold a price
      int deviceType = -5; // -5 = error, 0 = phone, 1 = tablet
      String type;
      
      // Create a Scanner object for keyboard input.
      Scanner keyboard = new Scanner(System.in);

      // Enter Device Type
      while( deviceType != 0 || deviceType != 1 )
      {
	      System.out.print("Enter the letter for the type of device (P for phone, T for Tablet): ");
	      type = keyboard.nextLine();
      	      if(type.equals("P"))
		deviceType=0;
	      else if(type.equals("T"))
		deviceType=1;
	      else
		System.out.print("Input Error");
      }
      
      // Get the manufacturer name.
      System.out.print("Enter the manufacturer: ");
      testMan = keyboard.nextLine();
      
      // Get the model number.
      System.out.print("Enter the model number: ");
      testMod = keyboard.nextLine();
      
      // Get the retail price.
      System.out.print("Enter the retail price: ");
      testPrice = keyboard.nextDouble();
      
      // Create an instance of the CellPhone class,
      // passing the data that was entered as arguments
      // to the constructor.
	if(deviceType == 0)
      		CellPhone phone = new CellPhone(testMan, testMod, testPrice);
	else
		Tablet tab = new Tablet(testMan, testMod, testPrice);

      // Get the data from the phone and display it.
      System.out.println();
      System.out.println("Here is the data that you provided:");
	if(deviceType == 0 )
	{
		System.out.println("Device type: Phone");
	      System.out.println("Manufacturer: " + phone.getManufact());
	      System.out.println("Model number: " + phone.getModel());
	      System.out.println("Retail price: " + phone.getRetailPrice());
	}
	else
	{
		System.out.println("Device type: Tablet");
		System.out.println("Manufacturer: " + tab.getManufact());
	      System.out.println("Model number: " + tab.getModel());
	      System.out.println("Retail price: " + tab.getRetailPrice());
	}
   }
}
