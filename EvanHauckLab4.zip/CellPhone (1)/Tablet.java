public class Tablet {

	private String manufact;
	private String model;
	private double retailPrice;

	public Tablet(String man, String mod, double price) {
		manufact = man;
      		model = mod;
      		retailPrice = price;
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param mod
	 */
	public void setMod(String mod) {
		this.model = mod;
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param man
	 */
	public void setManufact(String man) {
		this.manufact = man;
	}

	/**
	 * 
	 * @param price
	 */
	public void setRetailPrice(double price) {
		this.retailPrice = price;
	}

	public String getModel() {
		return model;
	}

	public double getRetailPrice() {
		return retailPrice;
	}

	public String getManufact() {
		return manufact;
	}

}
